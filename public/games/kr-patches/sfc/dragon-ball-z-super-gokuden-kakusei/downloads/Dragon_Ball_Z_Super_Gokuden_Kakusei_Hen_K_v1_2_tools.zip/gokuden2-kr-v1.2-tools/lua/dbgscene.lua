package.path = "/path/to/gokuden2-kr-v1.2-tools/lua/?.lua;" .. package.path
local L = require("lib")
local n=0
local sc=tonumber(os.getenv("TARGET"),16)
local maxf=tonumber(os.getenv("MAXF") or "3000")
local every=tonumber(os.getenv("EVERY") or "30")
local period=tonumber(os.getenv("PERIOD") or "70")
emu.addEventCallback(function()
  n=n+1
  L.release()
  if n==430 then emu.write16(0x7E029C,sc,emu.memType.snesMemory) end
  if (n>=250 and n<254) or (n>=450 and n<454) or (n>600 and n%period<3) then L.press({a=true}) end
  if os.getenv("QUIZ") and n>600 and n%period>=40 and n%period<43 then L.press({x=true}) end
  local ev=tonumber(os.getenv("EVERY") or "0")
  if (ev>0 and n%ev==0) or (ev==0 and n>600 and n%period==period-4) then L.shot(string.format("q%05d.png",n)) end
  if n==maxf-1 then L.shot("end.png") end
  if n>=maxf then emu.stop(0) end
end, emu.eventType.endFrame)
local idlog=io.open(os.getenv("SHOT_DIR").."/ids.txt","w")
local last=-1
emu.addMemoryCallback(function(a)
  local id=(a-0x988000)//2+0x200
  if id~=last then last=id idlog:write(string.format("%d %03x\n",n,id)) idlog:flush() end
end, emu.callbackType.read, 0x988000, 0x989C00, emu.cpuType.snes, emu.memType.snesMemory)
