#!/bin/zsh
# Build v1.2 from the Japanese ROM and the v1.1 IPS.
# usage: tools/build.sh   (outputs super-gokuden-kr-v1.2.smc and release IPS)
set -e
cd "$(dirname $0)/.."
mkdir -p work release/v1.2
python3 tools/ips.py apply super-gokuden-jp.smc v1.1/v1.1.ips work/build-v1.1.smc
python3 tools/fix_overwrites.py super-gokuden-jp.smc work/build-v1.1.smc work/build-fixed.smc
python3 tools/title.py work/build-fixed.smc work/build-title.smc --no-balls
python3 tools/dialogue_patch.py super-gokuden-jp.smc work/build-title.smc tables/dialogue-v1.2.tsv super-gokuden-kr-v1.2.smc tables/kr-v1.2.txt
python3 tools/credits.py super-gokuden-kr-v1.2.smc
python3 tools/fixsum.py super-gokuden-kr-v1.2.smc
python3 tools/ips.py make super-gokuden-jp.smc super-gokuden-kr-v1.2.smc "release/v1.2/Dragon Ball Z Super Gokuden - Kakusei Hen (K) v1.2.ips"
python3 -c "import zlib;print('CRC32 %08X'%zlib.crc32(open('super-gokuden-kr-v1.2.smc','rb').read()))"
