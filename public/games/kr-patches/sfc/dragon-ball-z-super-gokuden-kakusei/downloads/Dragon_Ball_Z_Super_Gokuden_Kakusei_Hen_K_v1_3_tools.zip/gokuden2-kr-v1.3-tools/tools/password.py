"""Make the Totsugeki-hen password readable on the Kakusei-hen input screen.

usage: password.py jp.smc in.smc out.smc table.txt

Totsugeki-hen v1.1 shows its ending password with its own Korean glyphs, one
per kana code. The input screen here must show the same glyph for each symbol,
and what a cell enters must match the pair table the checker reads:

  $81:8D56 / $81:8E00  code each hiragana / katakana cell enters (85 each,
                       index = row * 15 + column)
  $84:A3E0 / $84:A4D0  the two grids drawn on screen (16-bit strings)
  $83:A60E             256 pairs of codes; the checker ($83:A1F8) turns each
                       two typed characters into the byte whose pair matches
  $83:AEB0             name conversion: the name bytes in the password are
                       Totsugeki-hen codes listed at $83:AD58; the same index
                       here is the code the name is shown with

Every symbol gets one Kakusei-hen code whose glyph is the Korean letter in
tables/totsugeki-password.tsv, and all five tables use that code. Letters the
font lacks are drawn into unused glyph slots, like dialogue_patch.py does.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import dialogue_patch as dp  # noqa: E402
from dialogue import off, words  # noqa: E402
from extract import load  # noqa: E402
from usedsheet import N  # noqa: E402

ROOT = os.path.join(os.path.dirname(__file__), "..")
ENTRY = (off(0x81, 0x8D56), off(0x81, 0x8E00))
GRID = (off(0x84, 0xA3E0), off(0x84, 0xA4D0))
PAIRS = off(0x83, 0xA60E)
NAME_FROM, NAME_TO, NAME_LEN = off(0x83, 0xAD58), off(0x83, 0xAEB0), 171
CELLS = 85


def w16(rom, o):
    return rom[o] | rom[o + 1] << 8


def put16(rom, o, v):
    rom[o], rom[o + 1] = v & 0xFF, v >> 8


def grid_offsets(base):
    """File offset of each cell in a drawn grid: rows of ' ' + 5 + ' ' + 5 + ' ' + 5 + newline."""
    out = []
    for cell in range(CELLS):
        r, c = divmod(cell, 15)
        out.append(base + 2 * (r * 19 + 1 + c + c // 5))
    return out


def counterpart(kana):
    """Hiragana <-> katakana; Totsugeki-hen uses hiragana for some look-alike symbols."""
    o = ord(kana)
    if 0x3041 <= o <= 0x3096:
        return chr(o + 0x60)
    if 0x30A1 <= o <= 0x30F6:
        return chr(o - 0x60)
    return None


def main():
    jp = open(sys.argv[1], "rb").read()
    rom = bytearray(open(sys.argv[2], "rb").read())
    table = load(sys.argv[4])
    jt = load(os.path.join(ROOT, "tables", "jp.txt"))

    letters, pairs = {}, []
    for line in open(os.path.join(ROOT, "tables", "totsugeki-password.tsv"), encoding="utf-8"):
        p = line.rstrip("\n").split("\t")
        if line.startswith("#"):
            continue
        if p[0] == "pair":
            pairs.append((int(p[2], 16), int(p[3], 16)))
        else:
            letters[int(p[0], 16)] = (p[1], p[3])
    symbols = sorted({c for pair in pairs for c in pair})
    targets = [letters[c][1] for c in symbols]
    if len(set(targets)) != len(targets):
        sys.exit("two password symbols would show the same letter")

    enc = {}
    for c in sorted(table):
        enc.setdefault(table[c], c)
    names = {letters[c][1] for c in letters if letters[c][1] not in ("⋮", "ー", "")}
    missing = sorted((set(targets) | names) - set(enc))
    if missing:
        keep = set()
        for i in range(N):
            bank, _, p = dp.pointer(rom, i)
            if p >= 0x8000:
                keep.update(dp.canon(w & 0x7FFF) for w in words(rom, off(bank, p)) if w != 0x0A)
        keep |= dp.other_text_codes(jp, rom)
        keep |= {dp.canon(enc[t]) for t in targets if t in enc}
        free = [c for c in sorted(table) if 0x100 <= c < 0x900 and dp.canon(c) not in keep and table[c] != " "]
        if len(missing) > len(free):
            sys.exit(f"need {len(missing)} new glyphs, only {len(free)} free slots")
        for ch, c in zip(missing, free):
            dp.write_glyph(rom, c, dp.draw_glyph(ch))
            print(f"new glyph {ch} -> {c:03x} (was {table[c]})")
            for k in [k for k, v in enc.items() if v == c]:
                del enc[k]
            enc[ch] = c
            table[c] = ch
        with open(sys.argv[4], "w", encoding="utf-8") as f:
            f.writelines(f"{c:03x}={table[c]}\n" for c in sorted(table))

    code_of = {c: enc[letters[c][1]] for c in symbols}

    for i, (a, b) in enumerate(pairs):
        put16(rom, PAIRS + 4 * i, code_of[a])
        put16(rom, PAIRS + 4 * i + 2, code_of[b])

    name_code = {}
    for i in range(NAME_LEN):
        letter = letters.get(w16(jp, NAME_FROM + 2 * i), ("", ""))[1]
        if letter in enc:
            name_code[w16(jp, NAME_TO + 2 * i)] = enc[letter]

    by_kana = {letters[c][0]: c for c in symbols}
    changed = 0
    for entry, grid in zip(ENTRY, GRID):
        cells = grid_offsets(grid)
        for cell in range(CELLS):
            kana = jt.get(w16(jp, entry + 2 * cell), "")
            if w16(jp, cells[cell]) != w16(jp, entry + 2 * cell):
                sys.exit(f"grid layout differs from the entry table at cell {cell}")
            sym = by_kana.get(kana, by_kana.get(counterpart(kana) or ""))
            if sym is not None:
                code = code_of[sym]
            else:
                # Not a password symbol: show the letter a Totsugeki-hen name
                # gets for this kana; gaps in the や/わ rows stay blank.
                code = name_code.get(w16(jp, entry + 2 * cell), w16(jp, entry + 2 * cell))
            put16(rom, entry + 2 * cell, code)
            put16(rom, cells[cell], code)
            changed += 1

    for i in range(NAME_LEN):
        jcode = w16(jp, NAME_TO + 2 * i)
        put16(rom, NAME_TO + 2 * i, name_code.get(jcode, jcode))

    open(sys.argv[3], "wb").write(rom)
    print(f"{len(symbols)} password symbols, {changed} input cells, {NAME_LEN} name letters")


if __name__ == "__main__":
    main()
