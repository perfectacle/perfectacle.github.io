#!/bin/zsh
# usage: run_all.sh [core ...] -> out/<scenario>-<core>-<rom>/ and results.txt (appends)
# roms/: jp.sfc, v10.sfc, v11.sfc, v11h.smc (512-byte copier header), save.srm (made by v1.0)
# cores/: <core>_libretro.dylib
cd "$(dirname $0)"
export LRVARS="supafaust_thread_affinity_ppu=0x0,supafaust_thread_affinity_emu=0x0"
cores=(${@:-bsnes bsnes_hd_beta snes9x snes9x2010 mednafen_supafaust mesen-s})
for core in $cores; do
  for rom in jp v10 v11 v11h; do
    f=roms/$rom.sfc; [[ $rom == v11h ]] && f=roms/v11h.smc
    for sc in new cont; do
      d=out/$sc-$core-$rom; rm -rf $d; mkdir -p $d
      if [[ $sc == cont ]]; then python3 lr.py cores/${core}_libretro.dylib $f $d s_$sc.txt roms/save.srm > $d.log 2>&1
      else python3 lr.py cores/${core}_libretro.dylib $f $d s_$sc.txt > $d.log 2>&1; fi
      echo "$sc $core $rom exit=$? $(grep -E '^OK|LOAD FAILED|terminat|Segmentation' $d.log | tail -1) last=$(tail -1 $d/wram.log 2>/dev/null)" >> results.txt
    done
  done
done
